'use client';

import { useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2, Upload, Sparkles, Youtube, Film, Link2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { importTranscriptAction } from '@/lib/actions/projects';
import { transcribeMediaAction, importMediaFromUrlAction } from '@/lib/actions/transcription';
import { createClient } from '@/lib/supabase/client';
import { DEMO_TRANSCRIPT_TEXT } from '@/lib/content/demo-transcript';
import { useDictionary } from '@/lib/i18n/dictionary-provider';

const MAX_TEXT_FILE_SIZE_BYTES = 5 * 1024 * 1024;
const MAX_MEDIA_FILE_SIZE_BYTES = 25 * 1024 * 1024;

const EXTENSION_TO_SOURCE: Record<string, 'txt' | 'srt' | 'vtt'> = {
  txt: 'txt',
  srt: 'srt',
  vtt: 'vtt',
};

const MEDIA_EXTENSION_TO_TYPE: Record<string, 'video' | 'audio'> = {
  mp4: 'video',
  mov: 'video',
  webm: 'video',
  mp3: 'audio',
  wav: 'audio',
  m4a: 'audio',
};

export function ContentSourcePanel({
  projectId,
  workspaceId,
  language,
}: {
  projectId: string;
  workspaceId: string;
  language: string;
}) {
  const router = useRouter();
  const t = useDictionary();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaInputRef = useRef<HTMLInputElement>(null);
  const [pastedText, setPastedText] = useState('');
  const [mediaUrl, setMediaUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [isImportingUrl, setIsImportingUrl] = useState(false);

  async function handleImport(params: {
    sourceType: 'manual' | 'txt' | 'srt' | 'vtt';
    text: string;
    originalFilename?: string;
    storagePath?: string;
  }) {
    setIsSubmitting(true);
    const result = await importTranscriptAction({
      projectId,
      sourceType: params.sourceType,
      text: params.text,
      originalFilename: params.originalFilename,
      storagePath: params.storagePath,
      language,
    });
    setIsSubmitting(false);

    if (!result.success) {
      toast.error(result.error.message);
      return;
    }

    toast.success(t.projects.source.importSuccess);
    router.refresh();
  }

  async function handlePasteSubmit() {
    await handleImport({ sourceType: 'manual', text: pastedText });
  }

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    const extension = file.name.split('.').pop()?.toLowerCase() ?? '';
    const sourceType = EXTENSION_TO_SOURCE[extension];
    if (!sourceType) {
      toast.error(t.projects.source.unsupportedTextFormat);
      return;
    }
    if (file.size > MAX_TEXT_FILE_SIZE_BYTES) {
      toast.error(t.projects.source.textFileTooLarge);
      return;
    }

    setIsSubmitting(true);
    try {
      const text = await file.text();
      const storagePath = `${workspaceId}/${projectId}/${Date.now()}-${file.name}`;
      const supabase = createClient();
      const { error: uploadError } = await supabase.storage
        .from('project-sources')
        .upload(storagePath, file, { contentType: file.type || 'text/plain' });

      if (uploadError) {
        toast.error(t.projects.source.originalFileSaveError);
      }

      await handleImport({
        sourceType,
        text,
        originalFilename: file.name,
        storagePath: uploadError ? undefined : storagePath,
      });
    } catch {
      toast.error(t.projects.source.fileReadError);
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleMediaFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    const extension = file.name.split('.').pop()?.toLowerCase() ?? '';
    const mediaType = MEDIA_EXTENSION_TO_TYPE[extension];
    if (!mediaType) {
      toast.error(t.projects.source.unsupportedMediaFormat);
      return;
    }
    if (file.size > MAX_MEDIA_FILE_SIZE_BYTES) {
      toast.error(t.projects.source.mediaFileTooLarge);
      return;
    }

    setIsTranscribing(true);
    try {
      const storagePath = `${workspaceId}/${projectId}/${Date.now()}-${file.name}`;
      const supabase = createClient();
      const { error: uploadError } = await supabase.storage
        .from('project-sources')
        .upload(storagePath, file, { contentType: file.type || 'application/octet-stream' });

      if (uploadError) {
        toast.error(t.projects.source.mediaUploadError);
        return;
      }

      const result = await transcribeMediaAction({
        projectId,
        sourceType: mediaType,
        storagePath,
        originalFilename: file.name,
        language,
      });

      if (!result.success) {
        toast.error(result.error.message);
        return;
      }

      toast.success(t.projects.source.transcribeSuccess);
      router.refresh();
    } catch {
      toast.error(t.projects.source.mediaProcessError);
    } finally {
      setIsTranscribing(false);
    }
  }

  async function handleUseDemo() {
    await handleImport({ sourceType: 'manual', text: DEMO_TRANSCRIPT_TEXT });
  }

  async function handleImportFromUrl() {
    if (!mediaUrl.trim()) return;

    setIsImportingUrl(true);
    const result = await importMediaFromUrlAction({ projectId, sourceUrl: mediaUrl.trim(), language });
    setIsImportingUrl(false);

    if (!result.success) {
      toast.error(result.error.message);
      return;
    }

    toast.success(t.projects.source.transcribeSuccess);
    setMediaUrl('');
    router.refresh();
  }

  return (
    <div className="space-y-4">
      <Tabs defaultValue="paste">
        <TabsList>
          <TabsTrigger value="paste">{t.projects.source.pasteTab}</TabsTrigger>
          <TabsTrigger value="upload">{t.projects.source.uploadTab}</TabsTrigger>
          <TabsTrigger value="media">{t.projects.source.mediaTab}</TabsTrigger>
          <TabsTrigger value="demo">{t.projects.source.demoTab}</TabsTrigger>
        </TabsList>

        <TabsContent value="paste" className="space-y-3">
          <Textarea
            rows={8}
            placeholder={t.projects.source.pastePlaceholder}
            value={pastedText}
            onChange={(e) => setPastedText(e.target.value)}
          />
          <Button onClick={handlePasteSubmit} disabled={isSubmitting || pastedText.trim().length < 20}>
            {isSubmitting && <Loader2 className="h-4 w-4 animate-spin" />}
            {t.projects.source.useThisTranscript}
          </Button>
        </TabsContent>

        <TabsContent value="upload" className="space-y-3">
          <p className="text-sm text-muted-foreground">{t.projects.source.uploadFormats}</p>
          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,.srt,.vtt"
            className="hidden"
            onChange={handleFileChange}
          />
          <Button variant="outline" onClick={() => fileInputRef.current?.click()} disabled={isSubmitting}>
            {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
            {t.projects.source.selectFile}
          </Button>
        </TabsContent>

        <TabsContent value="media" className="space-y-3">
          <p className="text-sm text-muted-foreground">{t.projects.source.mediaFormats}</p>
          <input
            ref={mediaInputRef}
            type="file"
            accept=".mp4,.mov,.webm,.mp3,.wav,.m4a"
            className="hidden"
            onChange={handleMediaFileChange}
          />
          <Button
            variant="outline"
            onClick={() => mediaInputRef.current?.click()}
            disabled={isTranscribing}
          >
            {isTranscribing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Film className="h-4 w-4" />}
            {isTranscribing ? t.projects.source.transcribing : t.projects.source.selectMedia}
          </Button>

          <div className="flex items-center gap-3 pt-1 text-xs text-muted-foreground">
            <div className="h-px flex-1 bg-border" />
            {t.projects.source.orPasteLink}
            <div className="h-px flex-1 bg-border" />
          </div>
          <p className="text-xs text-muted-foreground">{t.projects.source.linkHint}</p>
          <div className="flex gap-2">
            <Input
              placeholder={t.projects.source.linkPlaceholder}
              value={mediaUrl}
              onChange={(e) => setMediaUrl(e.target.value)}
              disabled={isImportingUrl}
            />
            <Button
              variant="outline"
              onClick={handleImportFromUrl}
              disabled={isImportingUrl || !mediaUrl.trim()}
            >
              {isImportingUrl ? <Loader2 className="h-4 w-4 animate-spin" /> : <Link2 className="h-4 w-4" />}
              {t.projects.source.useLink}
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="demo" className="space-y-3">
          <p className="text-sm text-muted-foreground">{t.projects.source.demoDescription}</p>
          <Button onClick={handleUseDemo} disabled={isSubmitting}>
            {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            {t.projects.source.useDemoTranscript}
          </Button>
        </TabsContent>
      </Tabs>

      <div>
        <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {t.projects.source.comingSoonLabel}
        </p>
        <div className="grid gap-3 sm:grid-cols-3">
          {[{ icon: Youtube, label: t.projects.source.connectYoutube }].map((item) => (
            <Card key={item.label} className="opacity-60">
              <CardContent className="flex items-center gap-3 p-4">
                <item.icon className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">{item.label}</span>
                <Badge variant="outline" className="ml-auto">
                  {t.projects.source.comingSoonLabel}
                </Badge>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
