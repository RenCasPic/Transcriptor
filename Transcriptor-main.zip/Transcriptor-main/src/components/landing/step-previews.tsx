import { Upload, Sparkles, PenLine, CheckCircle2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { FadeIn } from './fade-in';

/**
 * Mini animaciones ilustrativas (CSS puro) de cada paso del flujo. No son
 * capturas reales de la app: sirven como referencia visual rápida mientras
 * no haya grabaciones de pantalla del producto. Se pueden reemplazar por
 * GIFs/videos reales sin cambiar el resto de la landing.
 */
const FRAMES = [
  (
    <div key="upload" className="flex h-32 items-center justify-center rounded-lg border-2 border-dashed border-indigo-300 bg-indigo-50">
      <Upload className="h-8 w-8 animate-bounce text-indigo-500" />
    </div>
  ),
  (
    <div key="generate" className="flex h-32 flex-col justify-center gap-2 rounded-lg bg-violet-50 p-5">
      <div className="flex items-center gap-1.5 text-violet-500">
        <Sparkles className="h-3.5 w-3.5 animate-pulse" />
      </div>
      <div className="h-2 w-3/4 animate-pulse rounded bg-violet-300" />
      <div className="h-2 w-full animate-pulse rounded bg-violet-300 [animation-delay:200ms]" />
      <div className="h-2 w-2/3 animate-pulse rounded bg-violet-300 [animation-delay:400ms]" />
    </div>
  ),
  (
    <div key="edit" className="flex h-32 flex-col justify-center gap-2 rounded-lg bg-amber-50 p-5">
      <div className="flex items-center gap-1 text-amber-500">
        <PenLine className="h-3.5 w-3.5" />
      </div>
      <div className="h-2 w-full rounded bg-amber-200" />
      <div className="flex items-center gap-1">
        <div className="h-2 w-2/3 rounded bg-amber-300" />
        <div className="h-3.5 w-0.5 animate-pulse bg-amber-500" />
      </div>
      <div className="h-2 w-1/2 rounded bg-amber-200" />
    </div>
  ),
  (
    <div key="publish" className="flex h-32 items-center justify-center rounded-lg bg-emerald-50">
      <div className="flex h-12 w-12 animate-pulse items-center justify-center rounded-full bg-emerald-500 text-white">
        <CheckCircle2 className="h-6 w-6" />
      </div>
    </div>
  ),
];

export function StepPreviews({
  title,
  subtitle,
  steps,
}: {
  title: string;
  subtitle: string;
  steps: string[];
}) {
  return (
    <section className="py-20">
      <div className="container">
        <FadeIn className="mx-auto mb-12 max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight">{title}</h2>
          <p className="mt-3 text-muted-foreground">{subtitle}</p>
        </FadeIn>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <FadeIn key={step} delayMs={index * 100}>
              <Card className="overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
                <div className="flex items-center gap-1.5 border-b bg-muted/40 px-3 py-2">
                  <span className="h-2 w-2 rounded-full bg-rose-300" />
                  <span className="h-2 w-2 rounded-full bg-amber-300" />
                  <span className="h-2 w-2 rounded-full bg-emerald-300" />
                </div>
                {FRAMES[index]}
                <CardContent className="p-3">
                  <p className="text-center text-xs font-medium text-muted-foreground">{step}</p>
                </CardContent>
              </Card>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}
